# PAGASA NCR-PRSD Advisory Watcher

Pings a Discord channel the moment DOST-PAGASA's NCR-PRSD office issues a new:

- Rainfall Advisory
- Heavy Rainfall Warning
- Thunderstorm Advisory / Thunderstorm Watch

**Why this watches PAGASA's own site instead of scraping Facebook directly:**
Facebook actively blocks/rate-limits automated scraping and requires either
login credentials or a Meta app-review process to read another page's posts
via the official API — both fragile and slow for a personal project.
PAGASA's own regional forecast page publishes the *exact same bulletin text*,
at the same time, as a stable public webpage:

`https://pagasa.dost.gov.ph/regional-forecast/ncrprsd`

(PAGASA's own legend page confirms these bulletins are "disseminated via SMS,
Social Media, and website" together — so this is the same information,
just from a source that's actually reliable to poll.)

Note: "NCR-PRSD" is PAGASA's forecast division name, but its forecast area
includes nearby provinces (Bataan, Batangas, Bulacan, Cavite, Laguna, Nueva
Ecija, Pampanga, Quezon, Rizal, Tarlac, Zambales) in addition to Metro Manila
— advisories will mention whichever of these areas are actually affected.

## How it works

1. A GitHub Actions workflow runs `watch_pagasa.py` on a schedule (every ~10
   minutes), for free, in GitHub's cloud — no need to keep your PC on.
2. The script fetches the PAGASA page, extracts every advisory currently
   listed, and compares them against `state.json` (which advisories it's
   already alerted on).
3. Any advisory it hasn't seen before gets posted to your Discord channel via
   a webhook, and gets recorded in `state.json` so it won't be posted again.
4. The workflow commits the updated `state.json` back to the repo after each
   run, so state persists between runs.

## Setup (~5 minutes)

### 1. Create a Discord webhook
In your Discord server: **Server Settings → Integrations → Webhooks → New
Webhook**. Pick the channel you want alerts in, then copy the webhook URL.

### 2. Create a GitHub repo
Create a new repository (public or private both work fine) and upload all
the files in this project, **keeping the folder structure** — in particular
`.github/workflows/watch.yml` must stay at that exact path.

### 3. Add the webhook URL as a secret
In the repo: **Settings → Secrets and variables → Actions → New repository
secret**.
- Name: `DISCORD_WEBHOOK_URL`
- Value: the webhook URL from step 1

### 4. Run it once manually to initialize
Go to the **Actions** tab → "Watch PAGASA NCR-PRSD Advisories" → **Run
workflow**. This first run just records whatever advisories are currently
active as "already seen" (so you don't get dumped a wall of old advisories)
— it won't post anything to Discord yet.

### 5. Done
From here it runs automatically every 10 minutes and will post to Discord
whenever a genuinely new advisory appears.

## Adjusting it

- **Check frequency**: edit the `cron` line in `.github/workflows/watch.yml`
  (e.g. `*/5 * * * *` for every 5 minutes — GitHub's practical minimum).
- **Which advisory types trigger alerts**: edit the `KEYWORDS` list at the
  top of `watch_pagasa.py`.
- **A different PAGASA region** (Northern Luzon, Southern Luzon, Visayas,
  Mindanao): change `SOURCE_URL` to the matching page, e.g.
  `https://pagasa.dost.gov.ph/regional-forecast/slprsd`.

## A known GitHub quirk

GitHub automatically disables *scheduled* workflows in a repo that's had no
other activity (commits, etc.) for 60 days. If alerts seem to stop, check the
Actions tab — there's a one-click "Enable workflow" button if this happens.
